package com.nfproject.manicure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManicureApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManicureApplication.class, args);
	}

}
