package com.nfproject.manicure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManicureApplicationTests {

	@Test
	void contextLoads() {
	}

}
